Nowfir:
 todo:
 get id from database everytime a new user joins
 get age and gender from user and send to backend along with id to create a node
 connect bluetooth and get location whenever new contact
 send contact time and location along with id to backend
 In case of positive corona send notification along with id to backend
Paul:
 todo:
 Create and send back id to nowfir when requested
 Recieve everything send by nowfir, and make it in a form to add to neo4j
 
 
 
